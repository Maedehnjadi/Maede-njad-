name="maedeh nejad pashm forosh"

ascii_chars=[]

for char in name:
     ascii_chars.append(ord(chars))

print(ascii_chars)
[109, 97, 101, 100, 101, 104, 32, 110, 101, 106, 97, 100, 32, 112, 97, 115, 104,
 109, 32, 102, 111, 114, 111, 115, 104]